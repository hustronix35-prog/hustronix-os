# Deploy `plainlandingpage` to Netlify (manual)

This folder is the **only** publish root for your marketing site. It includes:

- Early-access form on the homepage (`#early-access`)
- Netlify Functions that save submissions (Netlify Blobs in production)
- Private viewer: **`/leads.html`** (password from env)

## Before you deploy (local test)

```bash
cd plainlandingpage
cp .env.leads.example .env.leads   # set EARLY_ACCESS_ADMIN_PASSWORD
npm install
npm run dev
```

1. Open **http://127.0.0.1:8888/** — submit the early-access form (use a test email).
2. Open **http://127.0.0.1:8888/leads.html** — password from **`.env.leads`** (see below).
3. Confirm the test row appears → **Refresh**.

Rebuild this folder from the repo when the Next landing changes:

```bash
# from repo root (API + web running on 3005 for export)
npm run build:web
npm run start:unified
npm run export:netlify-landing
npm run build:plainlandingpage
```

---

## Manual deploy on Netlify

### 1. Create the site

1. Go to [https://app.netlify.com](https://app.netlify.com) → **Add new site** → **Import an existing project** (or **Deploy manually**).
2. If using Git: connect the repo and set **Base directory** to `plainlandingpage`.
3. If deploying by drag-and-drop: zip the **`plainlandingpage`** folder contents (not the parent repo).

### 2. Build settings

| Setting | Value |
|--------|--------|
| **Base directory** | `plainlandingpage` (if repo root is Hustronix OS) |
| **Build command** | `npm install` |
| **Publish directory** | `.` (or `plainlandingpage` if base is repo root) |

`netlify.toml` in this folder already sets `publish = "."` and `functions` under `netlify/functions`.

### 3. Environment variable (required)

**Site configuration → Environment variables → Add variable**

| Key | Value |
|-----|--------|
| `EARLY_ACCESS_ADMIN_PASSWORD` | Same password as in local `.env.leads` |

Scope: **All scopes** (or at least Production).  
**Do not** commit `.env` or `.env.leads` to Git (use `.env.leads.example` as the template).

### 4. Deploy

- **Git:** push → Netlify builds automatically.
- **Manual:** drag the `plainlandingpage` folder to Netlify **Deploys → Deploy manually**.

Wait until status is **Published**.

### 5. Verify production

1. `https://YOUR-SITE.netlify.app/` — submit early access.
2. `https://YOUR-SITE.netlify.app/leads.html` — unlock with the same password as the env var.
3. Row should appear after **Refresh**.

Do not link `leads.html` from the public homepage (keep the URL private).

---

## Troubleshooting

| Problem | Fix |
|--------|-----|
| Form says it could not save | Redeploy after `npm install` build step; check **Functions** tab for errors |
| Leads 404 | Site must be on Netlify (functions do not run on static hosts) |
| Wrong password | `EARLY_ACCESS_ADMIN_PASSWORD` must match exactly; redeploy after changing |
| Empty list after submit | Wait a few seconds, click **Refresh**; check function logs |

---

## Files you must include in the deploy zip / Git

- `index.html`, `styles.css`, all `*.js` in this folder
- `leads.html`, `leads.js`, `site-pages.css`
- `netlify/functions/` (both functions + `_leads-store.mjs`)
- `package.json` (for `@netlify/blobs` at build time)
- `netlify.toml`
- `brand/`

Do **not** need: `_next/`, `node_modules/` (installed on build), `.env.leads` (use Netlify UI in production).
